package com.gigaspaces.kryo_example.common;

import java.io.Serializable;
import java.time.LocalDateTime;

public abstract class AbstractRecord implements RecordTimeStamp, Serializable {

  private static final long serialVersionUID = 8868920805845949343L;

  private LocalDateTime cacheUpdateTimeStamp;

  private LocalDateTime eventSrcTimeStamp;

  public AbstractRecord() {
  }

  public AbstractRecord(final LocalDateTime cacheUpdateTimeStamp, final LocalDateTime eventSrcTimeStamp) {
    super();
    this.cacheUpdateTimeStamp = cacheUpdateTimeStamp;
    this.eventSrcTimeStamp = eventSrcTimeStamp;
  }

  @Override
  public LocalDateTime getCacheUpdateTimeStamp() {
    return cacheUpdateTimeStamp;
  }

  @Override
  public void setCacheUpdateTimeStamp(final LocalDateTime cacheUpdateTimeStamp) {
    this.cacheUpdateTimeStamp = cacheUpdateTimeStamp;
  }

  @Override
  public LocalDateTime getEventSrcTimeStamp() {
    return eventSrcTimeStamp;
  }

  @Override
  public void setEventSrcTimeStamp(final LocalDateTime eventSrcTimeStamp) {
    this.eventSrcTimeStamp = eventSrcTimeStamp;
  }
}

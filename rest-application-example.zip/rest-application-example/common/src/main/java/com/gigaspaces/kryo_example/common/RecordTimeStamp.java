package com.gigaspaces.kryo_example.common;

import java.time.LocalDateTime;

public interface RecordTimeStamp {

  LocalDateTime getCacheUpdateTimeStamp();

  LocalDateTime getEventSrcTimeStamp();

  void setCacheUpdateTimeStamp(LocalDateTime cacheUpdateTimeStamp);

  void setEventSrcTimeStamp(LocalDateTime eventSrcTimeStamp);
}
